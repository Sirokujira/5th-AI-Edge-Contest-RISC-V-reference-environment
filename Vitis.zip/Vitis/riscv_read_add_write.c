
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "sleep.h"

#define REG(address) *(volatile unsigned int*)(address)

#define GPIO_BASE (0xA0010000) /* XPAR_AXI_GPIO_0_BASEADDR */
#define GPIO_DATA (GPIO_BASE + 0x0000)
#define GPIO_TRI  (GPIO_BASE + 0x0004)

#define IMEM_BASE  (0xA0000000)
#define DMEM_BASE  (0xA0002000)

// GPIO[0]=RISC_V_IMEM_RESET、RISC_V_DMEM_RESET
// GPIO[1]=LED0
// GPIO[2]=LED1

// This program is DMEM[0]+DMEM[1]=DMEM[2]
int main()
{
	unsigned int c;
    init_platform();

    print("Hello World\n\r");
    REG(GPIO_TRI) = 0x00;
	REG(GPIO_DATA) = 0x02; // LED0
    /* Memory access test */
    c = 0;
    REG(IMEM_BASE+0 ) = 0xA0002437; //  0: lui s0,0x41000
    REG(IMEM_BASE+4 ) = 0x00040413; //  4: mv  s0,s0
    REG(IMEM_BASE+8 ) = 0x00042603; //  8: lw  a2,0(s0) # 0x41000000
    REG(IMEM_BASE+12) = 0x00442683; //  C: lw  a3,4(s0)
    REG(IMEM_BASE+16) = 0x00d60733; // 10: add a4,a2,a3
    REG(IMEM_BASE+20) = 0x00e42423; // 14: sw  a4,0(s0) # 0x41000000
    REG(IMEM_BASE+24) = 0x0000006f; // 18: j   0x18
    REG(DMEM_BASE+0 ) = 0x00000012; //  0: 0x12
    REG(DMEM_BASE+4 ) = 0x00000034; //  4: 0x34
    sleep(1);
	REG(GPIO_DATA) = 0x04; // LED1
	sleep(1);
  	REG(GPIO_DATA) = 0x01; // Reset off
  	sleep(1);
  	REG(GPIO_DATA) = 0x00; // Reset on
  	sleep(1);
    c =  REG(DMEM_BASE+8);
    printf("%x\n\r",c);
    if(c==0x00000046){ // 0x12+0x34=0x46
    	printf("Pass\n\r");
    	REG(GPIO_DATA) = 0x04; // LED1
    }else{
    	printf("Fail\n\r");
    	REG(GPIO_DATA) = 0x06; // LED1,0
    }
    sleep(1);

    print("Successfully ran Hello World application\n\r");
    cleanup_platform();
    return 0;
}
